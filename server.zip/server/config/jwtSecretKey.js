module.exports = {
  jwtSecretKey: 'mai',
};
